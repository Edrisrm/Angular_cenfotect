export interface EventosI{
    nombreEvento: string;
    descripcion: string;
    fecha: string;
    
}