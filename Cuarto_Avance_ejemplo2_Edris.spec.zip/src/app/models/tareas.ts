export interface TareasI{
    nombreTarea: string;
    fecha: string;
    
}