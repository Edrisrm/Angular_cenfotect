// import { HttpClientModule } from '@angular/common/http';
// import { NgModule } from '@angular/core';
// import { ReactiveFormsModule } from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';

// import { AppRoutingModule } from './app-routing.module';
// import { AppComponent } from './app.component';
// import { EventosModule } from './eventos/eventos.module';
// import { FooterModule } from './footer/footer.module';
// import { NavbarModule } from './navbar/navbar.module';
// import { PrincipalComponent } from './principal/principal.component';
// import { TareasModule } from './tareas/tareas.module';

// @NgModule({
//   declarations: [
//     AppComponent,
//     PrincipalComponent
//   ],
//   imports: [
//     BrowserModule,
//     HttpClientModule,
//     AppRoutingModule,
//     ReactiveFormsModule,
//     NavbarModule,
//     FooterModule,
//     TareasModule,
//     EventosModule
//   ],
//   providers: [],
//   bootstrap: [AppComponent]
// })
// export class AppModule { }

import { Injector, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { createCustomElement } from '@angular/elements';  
import { PrincipalComponent } from './principal/principal.component';

@NgModule({
  declarations: [
    AppComponent,
    PrincipalComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  entryComponents: [AppComponent]
})
export class AppModule { 

  constructor(private injector: Injector) {
    const el = createCustomElement(PrincipalComponent, { injector });
    customElements.define('componentes-elemento', el);
  }
  
    ngDoBootstrap() {}



}