const fs = require('fs-extra');  
const concat = require('concat');

(async function build() {
    const files = [
        './dist/proyecto-angular-cenfotec/runtime.js',
        './dist/proyecto-angular-cenfotec/polyfills.js',
        './dist/proyecto-angular-cenfotec/scripts.js',
        './dist/proyecto-angular-cenfotec/main.js'
    ];

    await fs.ensureDir('elementos');
    await concat(files, 'elementos/componentes.js');
    await fs.copyFile(
        './dist/proyecto-angular-cenfotec/styles.css',
        'elementos/styles.css'
    );
})();
