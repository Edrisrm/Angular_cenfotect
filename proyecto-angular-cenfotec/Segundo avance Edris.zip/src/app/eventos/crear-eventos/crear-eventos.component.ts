import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-eventos',
  templateUrl: './crear-eventos.component.html',
  styleUrls: ['./crear-eventos.component.css']
})
export class CrearEventosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
