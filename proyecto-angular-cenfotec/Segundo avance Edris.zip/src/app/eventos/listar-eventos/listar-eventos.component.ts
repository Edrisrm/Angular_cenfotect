import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-eventos',
  templateUrl: './listar-eventos.component.html',
  styleUrls: ['./listar-eventos.component.css']
})
export class ListarEventosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
